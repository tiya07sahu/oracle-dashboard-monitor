import DashboardCharts from "./DashboardCharts";

function OverviewTab({ tablespaces, sessions, server }) {

  const totalServers = server.length;
  const healthyServers = Math.max(totalServers - 1, 0);
  const unhealthyServers = totalServers - healthyServers;

  const totalDB = 2;
  const healthyDB = 1;
  const unhealthyDB = 1;

  return (
    <>
      <div className="stats-grid">

        <div className="stat-card blue">
          <h3>Total Servers</h3>
          <h1>{totalServers}</h1>
        </div>

        <div className="stat-card green">
          <h3>Healthy Servers</h3>
          <h1>{healthyServers}</h1>
        </div>

        <div className="stat-card red">
          <h3>Unhealthy Servers</h3>
          <h1>{unhealthyServers}</h1>
        </div>

        <div className="stat-card blue">
          <h3>Total Databases</h3>
          <h1>{totalDB}</h1>
        </div>

        <div className="stat-card green">
          <h3>Healthy Databases</h3>
          <h1>{healthyDB}</h1>
        </div>

        <div className="stat-card red">
          <h3>Unhealthy Databases</h3>
          <h1>{unhealthyDB}</h1>
        </div>

      </div>

      <div className="middle-section">

  <div className="health-card">

    <h2>System Health Overview</h2>

    <p>
      Real-time monitoring of database and server
      infrastructure health.
    </p>

    <div className="progress">
      <div className="progress-fill"></div>
    </div>

    <h1>85%</h1>

    <p>Overall System Health</p>

  </div>

  <DashboardCharts />

</div>

<div className="alerts-card">

        <h2>Recent Alerts</h2>

        <table>

          <thead>
            <tr>
              <th>Severity</th>
              <th>Source</th>
              <th>Message</th>
              <th>Status</th>
            </tr>
          </thead>

          <tbody>

            <tr>
              <td>Warning</td>
              <td>Tablespace USERS</td>
              <td>Reached 85%</td>
              <td>Active</td>
            </tr>

            <tr>
              <td>Warning</td>
              <td>Server-03</td>
              <td>CPU Usage High</td>
              <td>Active</td>
            </tr>

            <tr>
              <td>Info</td>
              <td>Database</td>
              <td>Database Restarted</td>
              <td>Resolved</td>
            </tr>

            <tr>
              <td>Success</td>
              <td>Backup</td>
              <td>Backup Completed</td>
              <td>Done</td>
            </tr>

          </tbody>

        </table>

      </div>

    </>
  );
}

export default OverviewTab;