function DatabaseTab() {
  return (
    <div className="card">
      <h1>Database Analysis</h1>

      <p>Select one of the options below.</p>

      <div className="db-buttons">
        <button>Tablespace Analysis</button>
        <button>Performance Analysis</button>
        <button>Storage Analysis</button>
      </div>
    </div>
  );
}

export default DatabaseTab;