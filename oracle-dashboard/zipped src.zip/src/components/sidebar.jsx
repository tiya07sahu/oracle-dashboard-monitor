import { useState } from "react";
import { FaBars } from "react-icons/fa";
import { FaChevronDown, FaChevronRight } from "react-icons/fa";
import {
   FaBars,
  FaHome,
  FaServer,
  FaDatabase,
  FaUsers,
  FaChevronDown,
  FaChevronRight
} from "react-icons/fa";

function Sidebar({
  activeTab,
  setActiveTab,
  collapsed,
  setCollapsed
})
 {
     const [showDatabase, setShowDatabase] = useState(false);
  return (
    <div className={collapsed ? "sidebar collapsed" :"sidebar"}>
    
      <h2>Database Monitor</h2>
        
        <button
  className="toggle-btn"
  onClick={() => setCollapsed(!collapsed)}
>
  <FaBars />
   </button>

      <button
           className={activeTab === "overview" ? "active" : ""}
           onClick={() => setActiveTab("overview")}
>
             <FaHome />
              {!collapsed && <span>Overview</span>}
      </button>

      <button
        className={activeTab === "server" ? "active" : ""}
        onClick={() => setActiveTab("server")}
      >
        <FaServer />
            {!collapsed && <span>Servers</span>}
      </button>

      <button
  onClick={() => setShowDatabase(!showDatabase)}
>
   <FaDatabase />
   {!collapsed && <span>Database Analysis</span>}
</button>

{showDatabase && !collapsed && (
  <div className="submenu">

    <button
      className={activeTab === "tablespace" ? "active" : ""}
      onClick={() => setActiveTab("tablespace")}
    >
      Tablespaces
    </button>

    <button
      className={activeTab === "sessions" ? "active" : ""}
      onClick={() => setActiveTab("sessions")}
    >
      Sessions
    </button>

    <button
      className={activeTab === "performance" ? "active" : ""}
      onClick={() => setActiveTab("performance")}
    >
      Performance
    </button>

  </div>
)}

    </div>
  );
}

export default Sidebar;