import { useState } from "react";
function TablespaceTab({ tablespaces }) {
    const [filter,setFilter] = useState("ALL");
    const filteredTablespaces =
  filter === "ALL"
    ? tablespaces
    : tablespaces.filter(
        t => t.status === filter
      );
  return (
    <>

        <div className="filter-buttons">

<button onClick={() => setFilter("ALL")}>
All
</button>

<button onClick={() => setFilter("Normal")}>
Normal
</button>

<button onClick={() => setFilter("Needs Extension")}>
Needs Extension
</button>

</div>
      <div className="cards">

        <div className="summary-card">
          <h2>Total Tablespaces</h2>
          <p>{tablespaces.length}</p>
        </div>

        <div className="summary-card">
          <h2>Needs Extension</h2>
          <p>
            {
              tablespaces.filter(
                t => t.status === "Needs Extension"
              ).length
            }
          </p>
        </div>

        <div className="summary-card">
          <h2>Normal</h2>
          <p>
            {
              tablespaces.filter(
                t => t.status === "Normal"
              ).length
            }
          </p>
        </div>

      </div>
     
      <div className="card">
        <h2>Tablespace Monitoring</h2>

        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Max MB</th>
                <th>Allocated MB</th>
                <th>Free MB</th>
                <th>Used MB</th>
                <th>% Used</th>
                <th>Available Extension</th>
                <th>% Free</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              {filteredTablespaces.map((item, index) => (
                <tr
                  key={index}
                 style={{
                     backgroundColor:
                         item.status === "Needs Extension"
                             ? "#5a1f1f"
                            : "transparent"
                        }}
                >
                  <td>{item.tablespace_name}</td>
                  <td>{item.max_mb}</td>
                  <td>{item.allocated_mb}</td>
                  <td>{item.free_mb}</td>
                  <td>{item.used_mb}</td>
                  <td>{item.percentage_used}%</td>
                  <td>{item.available_extension_mb}</td>
                  <td>{item.percentage_free}%</td>
                  <td>{item.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </>
  );
}

export default TablespaceTab;