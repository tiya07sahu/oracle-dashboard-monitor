function AlertsTab() {
  return (
    <div className="card">
      <h1>Alerts Dashboard</h1>

      <p>No active alerts found.</p>
    </div>
  );
}

export default AlertsTab;
