
import { useEffect, useState } from "react";
import "./App.css";

import ServerTab from "./components/ServerTab";
import SessionTab from "./components/SessionTab";
import TablespaceTab from "./components/TablespaceTab";
import OverviewTab from "./components/OverviewTab";
import Sidebar from "./components/Sidebar";
import DatabaseTab from "./components/DatabaseTab";
import AlertsTab from "./components/AlertsTab";

function App() {
  const [tablespaces, setTablespaces] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [server, setServer] = useState([]);
  const [dbName, setDbName] = useState("rundb1");
  const [activeTab, setActiveTab] = useState("overview");
  const [filter, setFilter] = useState("ALL");
  const [collapsed, setCollapsed] = useState(false);
  const [search, setSearch] = useState("");
  const [darkMode,setDarkMode] = useState(true);
  // SERVER DATA (loads once)

useEffect(() => {
  fetch("http://127.0.0.1:8000/servers")
    .then((res) => res.json())
    .then((data) => {
      setServer(data);
    })
    .catch((err) => {
      console.error(err);
    });
}, []);


// DATABASE DATA (changes with RunDB1 / RunDB2)
useEffect(() => {
fetch(`http://127.0.0.1:8000/tablespaces/${dbName}`)
    .then((res) => {
      console.log("TABLESPACE STATUS:", res.status);
      return res.json();
    })
    .then((data) => {
      setTablespaces(data);
    })
    .catch((err) => {
      console.error(err);
    });

  fetch(`http://127.0.0.1:8000/sessions/${dbName}`)
    .then((res) => {
      console.log("SESSION STATUS:", res.status);
      return res.json();
    })
    .then((data) => {
      setSessions(data);
    })
    .catch((err) => {
      console.error(err);
    });

}, [dbName]);
console.log("TABLESPACES:", tablespaces);
console.log("SESSIONS:", sessions);
console.log("SERVER:", server);

  return (
  <div className={darkMode ? "app-layout dark" : "app-layout light"}>

    <Sidebar
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      collapsed={collapsed}
      setCollapsed={setCollapsed}
    />

    <div className="main-content">

      <div className="top-header">

  <div>
    <h1>Server And Database Monitoring Dashboard</h1>
    <p>Real-time Database Health & Performance Monitoring</p>
  </div>

  <div className="header-right">
    <button
      className="theme-btn"
      onClick={() => setDarkMode(!darkMode)}
    >
      {darkMode ? "☀ Light" : "🌙 Dark"}
    </button>

    <div className="time-box">
      {new Date().toLocaleString()}
    </div>
  </div>

</div>

      <select
        value={dbName}
        onChange={(e) => setDbName(e.target.value)}
      >
        <option value="rundb1">RunDB1</option>
        <option value="rundb2">RunDB2</option>
      </select>

      {activeTab === "overview" && (
        
        <OverviewTab
          tablespaces={tablespaces}
          sessions={sessions}
          server={server}
        />
          
      )}

      {activeTab === "server" && (
        <ServerTab server={server} />
      )}

      {activeTab === "performance" && (
   <div className="card">
      <h1>Performance Analysis</h1>
   </div>
    )}

      {activeTab === "tablespace" && (
        <TablespaceTab tablespaces={tablespaces} />
      )}

      {activeTab === "sessions" && (
        <SessionTab sessions={sessions} />
      )}

      {activeTab === "database" && (
    <DatabaseTab />
)}

{activeTab === "alerts" && (
    <AlertsTab />
)}

    </div>

  </div>
);

}

export default App